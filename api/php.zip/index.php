<!doctype html>
<html lang="en">

<?php include_once("header.php"); ?>

<?php include_once("body.php"); ?>

<?php include_once("script.php"); ?>

</html>