<?php include ("dbconn.php") ?>
<!DOCTYPE html>
<html lang="en">

<body class="hold-transition sidebar-mini">
            <script>alert('success '); </script>

</body>
</html>
